var express = require('express');
var router = express.Router();
const TodoModel = require('../models/todo')

// /* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Greeting Application' });
//   // res.render('index', {title: 'Express'})
// });
// module.exports = router;


// router.get('/hello', function(req, res, next) {
//   res.send('Hi');
// })
// module.exports = router;

// router.get('/books', function(req, res, next) {
//   console.log('Category: ' + req.query['category']);
//   console.log('Type: ' + req.query['type'])
// })
// module.exports = router;

// router.get('/', function(req, res, next) {
//   res.send('Hello, welcome to the Greeting App')
// });
// module.exports = router;

// router.get('/greet', function(req, res, next) {
//   const name = req.query.name;
//   res.send(`Good morning, ${name}`)
// })
// module.exports = router;

// router.get('/number', function(req, res, next) {
//   const day = req.query.num;
//   const now = new Date();
//   let dayNow = now.getDay();
//   var until = Math.abs(dayNow - day);
//   console.log(until)
//   res.send(`Day: ${day}`)
// })

// router.post('/', function(req, res, next) {
//   const {name, day, month, year} = req.body;
//   const today = new Date();
//   const birthDate = new Date(year, month - 1, day);
  
//   let age = today.getFullYear() - birthDate.getFullYear();
//   birthDate.setFullYear(today.getFullYear())
//   if (birthDate < today) {
//     birthDate.setFullYear(today.getFullYear() + 1);
//     age++;
//   }

//   const oneDay = 24 * 60 * 60 * 1000;
//   const dayUntilBirth = Math.round((birthDate - today) / oneDay);

//   const greeting = `Good Morning, ${name}`;
//   const message = `${dayUntilBirth} days left to your ${age}th birthday.`;
  
//   res.send(`<div class="container">
//         <form action="/" method="POST">
//           <div class="inputName" style="display: flex; flex-direction: column; align-items: center;">
//               <label for="name" class="inputName__text"><span style="font-size: 20px; margin-left: -105px;">Your name</span></label>
//               <input type="text" id="name" name="name" required style="width: 200px; height: 35px; margin-top: 5px;">
//             </div>


//             <div class="date-inputs" style="margin-top: 30px; text-align: center; margin-left: 12px;">
//                 <p class="date-input__text" style="font-size: 20px; margin-bottom: 5px; margin-left: -114px;">Date of birth</p>
//                 <input style="height: 30px; text-align: center;" type="number" name="day" placeholder="day" min="1" max="31" required>
//                 <input style="height: 30px; text-align: center;" type="number" name="month" placeholder="month" min="1" max="12" required>
//                 <input style="height: 30px; text-align: center;" type="number" name="year" placeholder="year" min="1900" max="2100" required>
//             </div>

//             <div class="btn" style="display: flex; justify-content: center; align-items: center; margin-top: 30px;">
//               <button style="background-color: blue; border: 1px solid black; margin: 10px; width: 130px; padding: 10px; color: white; cursor: pointer" class="btn__submit" type="submit">Submit</button>
//               <button style="background-color: transparent; border: 1px solid black; margin-left: 0 0 0 10px; width: 72px; padding: 10px; cursor: pointer" class="btn__clear" type="reset" onclick="window.location.href='/'">Clear</button>
//             </div>
//         </form>

//         <div class="message" style="width: 30%; height: 300px; background-color: transparent; border: 1px solid black; margin: 30px auto;">
//           <h2 style="margin-left: 50px;">
//             ${greeting}
//           </h2>

//           <p style="margin-left: 50px;">
//             ${message}
//           </p>
//         </div>
//     </div>`);

 
// })
// module.exports = router;


// router.get('/', function(req, res) {
//   let {title, user} = req.body;
//   let newTodo = new TodoModel({title: title, user: user, isDone: 0})
//   newTodo.save().then(() => {
//   console.log("New task is created")
//   res.render('index')
// }).catch(err => console.log(err))
// })
// module.exports = router;

// router.get('/', function(req, res) {
//   let {title, user} = req.body
//   TodoModel.deleteOne({title: "Book", user: "Alex", isDone: 0}).then(() => {
//     console.log("Done")
//   }
// ).catch(err => console.log(err))
// })
// module.exports = router;

router.get('/', async (req, res) => {
  try {
    const tasks = await TodoModel.find();
    res.render('index', {tasks})
  } catch(error) {
    res.status(500).send(error.message);
  }
})
module.exports = router;

router.post('/tasks', async (req, res) => {
  try {
    const title = req.body.title;
    await TodoModel.create({title})
    console.log(title)
    res.redirect('/')
  } catch(error) {
    res.status(500).send(error.message);
  }
})
module.exports = router;

router.post('/tasks/:id/mark', async (req, res) => {
  try {
    await TodoModel.findByIdAndUpdate(req.params.id, {isDone: true})
    res.redirect('/')
  } catch(error) {
    res.status(500).send(error.message)
  }
})
module.exports = router;

router.post('/tasks/:id/delete', async (req, res) => {
  try {
    await TodoModel.findByIdAndDelete(req.params.id);

    res.redirect('/')
  } catch(error) {
    res.status(500).send(error.message)
  }

})
module.exports = router;

